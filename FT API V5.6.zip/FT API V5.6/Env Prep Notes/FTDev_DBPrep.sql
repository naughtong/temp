INSERT INTO dmDATATYPE VALUES ('cMRRATING','ENUM  ',4,' ','N',' ','market rating','CREATE ','N',0)
/

INSERT INTO dmENUMVAL values ('cMRRATING',  0, 'EXCL',
  'Excellent' , 'EXCL', 'cEXCL',
   'excellent', 'N','CREATE ')
/

INSERT INTO dmENUMVAL values ('cMRRATING',  1, 'AVG',
  'Average' , 'AVG', 'cAVG',
   'average', 'N','CREATE ')
/

INSERT INTO dmENUMVAL values ('cMRRATING',  2, 'POOR',
  'Poor' , 'POOR', 'cPOOR',
   'poor rating', 'N','CREATE ')
/

INSERT INTO dmENUMVAL values ('sTABLE',  2, 'cMKTREP',
  'cmdMKTREP', 'cMKTREP', 'cdmMKTREP',
   ' ', 'N', 'CREATE ')
/

INSERT INTO dmENTITY values ('cMKTREP', 'cdmMKTREP', 'cMKTREP', 
 'cMKTREP', 
 ' ', ' ', ' ', 'N', 'N', 'DEL  ', 'N', 'CREATE ', 
 ' ', 'Name',' ','cdmMKTREP','N','N','Y','       ', 'N', 0, ' ', ' ', ' ', 'Y', 'N', 'N' )
/

INSERT INTO dmPROPERTY values ('Name', 'cMKTREP', 20,
 'Name',
 'N', 'STRING',  'Name',
 ' ',  'Name', 'NTBSTRING', 'sTEXT20',
 'Text', 'N', 'Y', 'Y', 'Y',  ' ', 'CREATE ',  ' ',
 'Name',  'sTEXT20', 'N' )
/
INSERT INTO dmPROPERTY values ('Rating', 'cMKTREP', 21,
 'market rating',
 'N', 'ENUM  ',  'Rating',
 'cMRRATING',  'Rating', 'STRING   ', 'cMRRATING',
 ' ', 'N', 'Y', 'Y', 'N',  ' ', 'CREATE ',  'EXCL',
 'Rating',  'cMRRATING', 'N' )
/
INSERT INTO dmPROPERTY values ('CommissionRate', 'cMKTREP', 22,
 'commission rate',
 'N', 'GRATES',  'CommissionRate',
 ' ',  'CommissionRate', 'FLT8     ', 'sIRATE',
 ' ', 'N', 'Y', 'Y', 'N',  ' ', 'CREATE ',  '0',
 'CommissionRate',  'sIRATE', 'N' )
/

INSERT INTO dmENTITY_INTERFACE values  
( 'cMKTREP', 'BASE', 'N', 'stkclientapi') 
/

INSERT INTO dmENTITY_INTERFACE values
( 'cMKTREP', 'IO', 'N', ' ')
/

INSERT INTO dmMETHOD values ('cMKTREP', 'BASE', 'VALIDATE', 'N', 
 'cValcMKTREP', 'CREATE ', 'N')
/

INSERT INTO dmDB_INDEX
values ( 'cMKTREP',1,'Y','N','Y','Generated Primary index', 'CREATE ', 'N', 'ALLTABLES')
/

INSERT INTO dmDB_INDEX_COL
values ('cMKTREP',1,1,'Name','CREATE ' )
/
