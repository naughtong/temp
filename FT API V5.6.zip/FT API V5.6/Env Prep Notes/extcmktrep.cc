#include "client/stkpublicapi.h"

mDECLARE_METHOD_BASE_VALIDATE( cValcMKTREP )

mDLLEXPORT int cValcMKTREP( sENTITY *Entity, void *StructPtr, sERRMSGLIST *Messages )
{
	cMKTREP *refCode = (cMKTREP *) StructPtr;
	int ret = sSUCCESS;
	char buf[sMAX_TXT];

	// -------------------------------------------------------
	// Do the checking here! Feel free to add/modify criterion
	// -------------------------------------------------------
		
	// Need to be more than 10 basis points
	if ( refCode->CommissionRate < 0.1 )
	{
		sprintf(buf,"The commission has to be more than 10 basis points");
		mValMessage(Messages, -100, buf, sERROR);
		ret = sERROR;
	}
	
	// return validation status
	return ret;
}

mDECLARE_METHOD_CLOSE

