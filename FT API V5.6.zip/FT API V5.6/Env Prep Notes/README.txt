Contents:

- FT_DDBPrep.sql - contain cMKTREP entity definition to use in labs
- extcmktrep.cc - contains validation function for cMKTREP entity

Installation instructions:
1. Use convertdb utility to load SQL into training database
2. Create a proper c:\train\SummitSparse project tree with lib, exe,include, src\stk\rtdata, src\stk\clientapi folders
3. Run genmeta utility to generate metadata files and scripts
4. Copy metadata files to sparse tree
5. Copy extcmktrep.cc to clientapi folder and build library
6. Build rtdata library
7. Use convertdb utility to load metadata.sql.applychanges
8. Test cMKTREP entity and validation functionality
